package com.ticket.service;

import com.ticket.dao.UserDao;
import com.ticket.model.User;

public class UserService {
    private UserDao userDao = new UserDao();

    // 用户登录
    public User login(String username, String password) {
        return userDao.login(username, password);
    }

    // 用户注册
    public boolean register(User user) {
        // 简单验证
        if (userDao.findByUsername(user.getUsername()) != null) {
            return false; // 用户名已存在
        }
        return userDao.register(user);
    }
}
