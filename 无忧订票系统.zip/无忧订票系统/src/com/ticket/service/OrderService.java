package com.ticket.service;

import com.ticket.dao.OrderDao;
import com.ticket.dao.OrderDetailDao;
import com.ticket.model.Order;
import com.ticket.model.OrderDetail;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;


public class OrderService {
    private OrderDao orderDao = new OrderDao();
    private OrderDetailDao orderDetailDao = new OrderDetailDao();

    // 创建订单
    public int createOrder(Order order, List<OrderDetail> details) {
        // 生成订单号
        String orderNumber = generateOrderNumber();
        order.setOrderNumber(orderNumber);

        // 创建订单
        int orderId = orderDao.createOrder(order);

        if (orderId > 0) {
            // 创建订单详情
            for (OrderDetail detail : details) {
                detail.setOrderId(orderId);
                orderDetailDao.addOrderDetail(detail);
            }
        }

        return orderId;
    }

    // 生成唯一订单号
    private String generateOrderNumber() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String dateStr = sdf.format(new Date());
        Random random = new Random();
        int randomNum = 1000 + random.nextInt(9000); // 4位随机数
        return "ORD" + dateStr + randomNum;
    }

    // 更新订单状态为已支付
    public boolean payOrder(int orderId) {
        return orderDao.updateOrderStatus(orderId, "paid");
    }

    // 取消订单（更新状态为已取消）
    public boolean cancelOrder(int orderId) {
        return orderDao.updateOrderStatus(orderId, "cancelled");
    }

    // 申请退款（更新状态为退款中）
    public boolean applyRefund(int orderId) {
        return orderDao.updateOrderStatus(orderId, "refunding");
    }

    // 根据用户ID查询订单
    public List<Order> getUserOrders(int userId) {
        return orderDao.findByUserId(userId);
    }

    // 根据ID查询订单
    public Order getOrderById(int id) {
        return orderDao.findById(id);
    }

    // 根据订单ID查询订单详情
    public List<OrderDetail> getOrderDetails(int orderId) {
        return orderDetailDao.findByOrderId(orderId);
    }
}