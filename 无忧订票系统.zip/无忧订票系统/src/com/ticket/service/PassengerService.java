package com.ticket.service;

import com.ticket.model.Passenger;
import com.ticket.util.DBUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PassengerService {
    // 添加乘客：表名改为 passengers
    public boolean addPassenger(Passenger passenger) {
        String sql = "INSERT INTO passengers (user_id, name, id_card, phone, passenger_type) VALUES (?, ?, ?, ?, ?)";
        try (
                Connection conn = DBUtil.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)
        ) {
            pstmt.setInt(1, passenger.getUserId());
            pstmt.setString(2, passenger.getName());
            pstmt.setString(3, passenger.getIdCard());
            pstmt.setString(4, passenger.getPhone());
            pstmt.setString(5, passenger.getType());
            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 查询乘客：表名改为 passengers
    public List<Passenger> getPassengersByUserId(int userId) {
        List<Passenger> passengers = new ArrayList<>();
        String sql = "SELECT id, user_id, name, id_card, phone, type FROM passengers WHERE user_id = ?";
        try (
                Connection conn = DBUtil.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)
        ) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Passenger p = new Passenger();
                p.setId(rs.getInt("id"));
                p.setUserId(rs.getInt("user_id"));
                p.setName(rs.getString("name"));
                p.setIdCard(rs.getString("id_card"));
                p.setPhone(rs.getString("phone"));
                p.setType(rs.getString("type"));
                passengers.add(p);
            }
            return passengers;
        } catch (SQLException e) {
            e.printStackTrace();
            return passengers;
        }
    }

    // 根据ID查询乘客：表名改为 passengers
    public Passenger getPassengerById(int id) {
        String sql = "SELECT id, user_id, name, id_card, phone, passenger_type FROM passengers WHERE id = ?";
        try (
                Connection conn = DBUtil.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)
        ) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Passenger p = new Passenger();
                p.setId(rs.getInt("id"));
                p.setUserId(rs.getInt("user_id"));
                p.setName(rs.getString("name"));
                p.setIdCard(rs.getString("id_card"));
                p.setPhone(rs.getString("phone"));
                p.setType(rs.getString("passenger_type"));
                return p;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}