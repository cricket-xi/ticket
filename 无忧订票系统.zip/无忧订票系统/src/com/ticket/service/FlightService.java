package com.ticket.service;
import com.ticket.dao.FlightDao;
import com.ticket.model.Flight;
import java.util.List;
import java.util.Comparator;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class FlightService {
    private FlightDao flightDao = new FlightDao();

    /**
     * 搜索航班（支持航空公司筛选、时间范围筛选、排序）
     * @param departureCity 出发城市
     * @param arrivalCity 到达城市
     * @param date 出发日期
     * @param selectedAirline 选中的航空公司（all表示全部）
     * @param selectedTimeRange 出发时间范围（如06:00-12:00）
     * @param sortBy 排序方式（recommend/price_asc/price_desc/time_asc/departure_time_asc）
     * @return 筛选排序后的航班列表
     */
    public List<Flight> searchFlights(String departureCity, String arrivalCity, String date,
                                      String selectedAirline, String selectedTimeRange, String sortBy) {
        // 从数据库获取航班列表
        List<Flight> flights = flightDao.searchFlights(
                departureCity,
                arrivalCity,
                date,
                selectedAirline,
                selectedTimeRange,
                sortBy
        );

        // 执行排序
        sortFlights(flights, sortBy);

        return flights;
    }

    /**
     * 对航班列表进行排序
     */
    private void sortFlights(List<Flight> flights, String sortBy) {
        if (sortBy == null || flights == null || flights.isEmpty()) {
            return;
        }

        switch (sortBy) {
            case "price_asc":
                flights.sort(Comparator.comparingDouble(Flight::getEconomyPrice));
                break;
            case "price_desc":
                flights.sort(Comparator.comparingDouble(Flight::getEconomyPrice).reversed());
                break;
            case "time_asc":
                flights.sort(Comparator.comparingInt(this::parseDurationToMinutes));
                break;
            case "departure_time_asc":
                // 按出发时间升序排序
                flights.sort(Comparator.comparing(Flight::getDepartureTime));
                break;
            default:
                // 默认推荐排序，不做处理
                break;
        }
    }

    /**
     * 解析飞行时长为分钟数，用于耗时排序
     */
    private int parseDurationToMinutes(Flight flight) {
        String duration = flight.getDuration();
        if (duration == null || duration.isEmpty()) {
            return 0;
        }

        int hours = 0;
        int minutes = 0;

        if (duration.contains("小时")) {
            String[] parts = duration.split("小时");
            hours = Integer.parseInt(parts[0].trim());

            if (parts.length > 1 && parts[1].contains("分钟")) {
                minutes = Integer.parseInt(parts[1].replace("分钟", "").trim());
            }
        } else if (duration.contains("分钟")) {
            minutes = Integer.parseInt(duration.replace("分钟", "").trim());
        }

        return hours * 60 + minutes;
    }

    // 根据ID查询航班
    public Flight getFlightById(int id) {
        return flightDao.findById(id);
    }
}
