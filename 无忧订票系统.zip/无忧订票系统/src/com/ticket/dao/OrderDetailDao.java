package com.ticket.dao;

import com.ticket.model.OrderDetail;
import com.ticket.util.DBUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderDetailDao {

    // 添加订单详情
    public boolean addOrderDetail(OrderDetail detail) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBUtil.getConnection();
            String sql = "INSERT INTO order_details (order_id, passenger_id, price) VALUES (?, ?, ?)";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, detail.getOrderId());
            ps.setInt(2, detail.getPassengerId());
            ps.setDouble(3, detail.getPrice());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(ps, conn);
        }
        return false;
    }

    // 根据订单ID查询订单详情
    public List<OrderDetail> findByOrderId(int orderId) {
        List<OrderDetail> details = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT od.*, p.name as passenger_name, p.id_card as passenger_id_card " +
                    "FROM order_details od JOIN passengers p ON od.passenger_id = p.id " +
                    "WHERE od.order_id = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, orderId);

            rs = ps.executeQuery();
            while (rs.next()) {
                OrderDetail detail = new OrderDetail();
                detail.setId(rs.getInt("id"));
                detail.setOrderId(rs.getInt("order_id"));
                detail.setPassengerId(rs.getInt("passenger_id"));
                detail.setPrice(rs.getDouble("price"));
                detail.setPassengerName(rs.getString("passenger_name"));
                detail.setPassengerIdCard(rs.getString("passenger_id_card"));

                details.add(detail);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return details;
    }
}
