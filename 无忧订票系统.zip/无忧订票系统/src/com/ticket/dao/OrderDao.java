package com.ticket.dao;

import com.ticket.model.Order;
import com.ticket.util.DBUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderDao {

    // 创建订单
    public int createOrder(Order order) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            String sql = "INSERT INTO orders (order_number, user_id, flight_id, cabin_type, total_price, status) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
            ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, order.getOrderNumber());
            ps.setInt(2, order.getUserId());
            ps.setInt(3, order.getFlightId());
            ps.setString(4, order.getCabinType());
            ps.setDouble(5, order.getTotalPrice());
            ps.setString(6, order.getStatus());

            ps.executeUpdate();

            // 获取生成的订单ID
            rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return -1;
    }

    // 更新订单状态
    public boolean updateOrderStatus(int orderId, String status) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBUtil.getConnection();
            // 关键修复：将"order"改为"orders"（避免使用SQL关键字作为表名）
            String sql = "UPDATE orders SET status = ? WHERE id = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, status);
            ps.setInt(2, orderId);

            int rowsAffected = ps.executeUpdate();
            // 打印日志用于调试
            System.out.println("更新订单状态SQL执行结果：影响行数=" + rowsAffected +
                    ", 订单ID=" + orderId + ", 目标状态=" + status);
            return rowsAffected > 0;
        } catch (SQLException e) {
            // 打印详细错误信息（关键调试信息）
            System.err.println("更新订单状态失败！订单ID=" + orderId + ", 错误信息：" + e.getMessage());
            e.printStackTrace();
        } finally {
            DBUtil.close(ps, conn);
        }
        return false;
    }

    // 根据用户ID查询订单
    public List<Order> findByUserId(int userId) {
        List<Order> orders = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT o.*, f.flight_number, f.airline, f.departure_city, f.arrival_city, f.departure_time " +
                    "FROM orders o JOIN flights f ON o.flight_id = f.id " +
                    "WHERE o.user_id = ? ORDER BY o.created_at DESC";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);

            rs = ps.executeQuery();
            while (rs.next()) {
                Order order = new Order();
                order.setId(rs.getInt("id"));
                order.setOrderNumber(rs.getString("order_number"));
                order.setUserId(rs.getInt("user_id"));
                order.setFlightId(rs.getInt("flight_id"));
                order.setCabinType(rs.getString("cabin_type"));
                order.setTotalPrice(rs.getDouble("total_price"));
                order.setStatus(rs.getString("status"));
                order.setCreatedAt(rs.getTimestamp("created_at"));
                order.setFlightNumber(rs.getString("flight_number"));
                order.setAirline(rs.getString("airline"));
                order.setDepartureCity(rs.getString("departure_city"));
                order.setArrivalCity(rs.getString("arrival_city"));
                order.setDepartureTime(rs.getTimestamp("departure_time"));

                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return orders;
    }

    // 根据ID查询订单
    public Order findById(int id) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT o.*, f.flight_number, f.airline, f.departure_city, f.departure_airport, " +
                    "f.arrival_city, f.arrival_airport, f.departure_time, f.arrival_time " +
                    "FROM orders o JOIN flights f ON o.flight_id = f.id WHERE o.id = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, id);

            rs = ps.executeQuery();
            if (rs.next()) {
                Order order = new Order();
                order.setId(rs.getInt("id"));
                order.setOrderNumber(rs.getString("order_number"));
                order.setUserId(rs.getInt("user_id"));
                order.setFlightId(rs.getInt("flight_id"));
                order.setCabinType(rs.getString("cabin_type"));
                order.setTotalPrice(rs.getDouble("total_price"));
                order.setStatus(rs.getString("status"));
                order.setCreatedAt(rs.getTimestamp("created_at"));
                order.setFlightNumber(rs.getString("flight_number"));
                order.setAirline(rs.getString("airline"));
                order.setDepartureCity(rs.getString("departure_city"));
                order.setDepartureAirport(rs.getString("departure_airport"));
                order.setArrivalCity(rs.getString("arrival_city"));
                order.setArrivalAirport(rs.getString("arrival_airport"));
                order.setDepartureTime(rs.getTimestamp("departure_time"));
                order.setArrivalTime(rs.getTimestamp("arrival_time"));

                return order;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return null;
    }
}

