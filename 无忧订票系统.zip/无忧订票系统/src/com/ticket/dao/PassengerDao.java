package com.ticket.dao;

import com.ticket.model.Passenger;
import com.ticket.util.DBUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PassengerDao {

    // 添加乘客
    public boolean addPassenger(Passenger passenger) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBUtil.getConnection();
            String sql = "INSERT INTO passengers (user_id, name, id_card, phone, type) VALUES (?, ?, ?, ?, ?)";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, passenger.getUserId());
            ps.setString(2, passenger.getName());
            ps.setString(3, passenger.getIdCard());
            ps.setString(4, passenger.getPhone());
            ps.setString(5, passenger.getType());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(ps, conn);
        }
        return false;
    }

    // 根据用户ID查询乘客
    public List<Passenger> findByUserId(int userId) {
        List<Passenger> passengers = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM passengers WHERE user_id = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);

            rs = ps.executeQuery();
            while (rs.next()) {
                Passenger passenger = new Passenger();
                passenger.setId(rs.getInt("id"));
                passenger.setUserId(rs.getInt("user_id"));
                passenger.setName(rs.getString("name"));
                passenger.setIdCard(rs.getString("id_card"));
                passenger.setPhone(rs.getString("phone"));
                passenger.setType(rs.getString("type"));

                passengers.add(passenger);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return passengers;
    }

    // 根据ID查询乘客
    public Passenger findById(int id) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM passengers WHERE id = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, id);

            rs = ps.executeQuery();
            if (rs.next()) {
                Passenger passenger = new Passenger();
                passenger.setId(rs.getInt("id"));
                passenger.setUserId(rs.getInt("user_id"));
                passenger.setName(rs.getString("name"));
                passenger.setIdCard(rs.getString("id_card"));
                passenger.setPhone(rs.getString("phone"));
                passenger.setType(rs.getString("type"));

                return passenger;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return null;
    }
}
