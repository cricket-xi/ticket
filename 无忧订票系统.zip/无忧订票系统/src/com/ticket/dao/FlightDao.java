package com.ticket.dao;
import com.ticket.model.Flight;
import com.ticket.util.DBUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FlightDao {

    /**
     * 搜索航班（带筛选和排序）
     */
    public List<Flight> searchFlights(String departureCity, String arrivalCity, String date,
                                      String selectedAirline, String selectedTimeRange, String sortBy) {
        List<Flight> flights = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getConnection();
            // 1. 构建SQL基础语句
            StringBuilder sql = new StringBuilder("SELECT * FROM flights WHERE 1=1 ");
            List<Object> params = new ArrayList<>();

            // 2. 添加基础搜索条件
            sql.append("AND departure_city = ? ");
            params.add(departureCity);
            sql.append("AND arrival_city = ? ");
            params.add(arrivalCity);
            sql.append("AND DATE(departure_time) = ? ");
            params.add(date);

            // 3. 添加航空公司筛选条件（非all时）
            if (selectedAirline != null && !"all".equals(selectedAirline)) {
                sql.append("AND airline = ? ");
                params.add(selectedAirline);
            }

            // 4. 添加出发时间范围筛选条件
            if (selectedTimeRange != null && !"all".equals(selectedTimeRange)) {
                String[] timeRange = selectedTimeRange.split("-");
                if (timeRange.length == 2) {
                    sql.append("AND TIME(departure_time) BETWEEN ? AND ? ");
                    params.add(timeRange[0]);
                    params.add(timeRange[1]);
                }
            }

            // 5. 添加排序条件
            sql.append("ORDER BY ");
            if (sortBy == null || "recommend".equals(sortBy)) {
                // 推荐排序：按出发时间升序（默认）
                sql.append("departure_time ASC ");
            } else if ("price_asc".equals(sortBy)) {
                // 价格低到高（默认按经济舱价格）
                sql.append("economy_price ASC ");
            } else if ("price_desc".equals(sortBy)) {
                // 价格高到低
                sql.append("economy_price DESC ");
            } else if ("time_asc".equals(sortBy)) {
                // 耗时短（需确保duration字段为可排序格式，如“02:30”）
                sql.append("TIMESTAMPDIFF(MINUTE, departure_time, arrival_time) ASC ");
            }

            // 6. 执行SQL
            ps = conn.prepareStatement(sql.toString());
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            rs = ps.executeQuery();

            // 7. 封装结果
            while (rs.next()) {
                Flight flight = new Flight();
                flight.setId(rs.getInt("id"));
                flight.setFlightNumber(rs.getString("flight_number"));
                flight.setAirline(rs.getString("airline"));
                flight.setDepartureCity(rs.getString("departure_city"));
                flight.setDepartureAirport(rs.getString("departure_airport"));
                flight.setArrivalCity(rs.getString("arrival_city"));
                flight.setArrivalAirport(rs.getString("arrival_airport"));
                flight.setDepartureTime(rs.getTimestamp("departure_time"));
                flight.setArrivalTime(rs.getTimestamp("arrival_time"));
                flight.setDuration(rs.getString("duration"));
                flight.setAircraft(rs.getString("aircraft"));
                flight.setEconomyPrice(rs.getDouble("economy_price"));
                flight.setBusinessPrice(rs.getDouble("business_price"));
                flight.setFirstClassPrice(rs.getDouble("first_class_price"));
                flight.setSeatsEconomy(rs.getInt("seats_economy"));
                flight.setSeatsBusiness(rs.getInt("seats_business"));
                flight.setSeatsFirstClass(rs.getInt("seats_first_class"));
                flights.add(flight);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return flights;
    }

    // 根据ID查询航班
    public Flight findById(int id) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT * FROM flights WHERE id = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                Flight flight = new Flight();
                flight.setId(rs.getInt("id"));
                flight.setFlightNumber(rs.getString("flight_number"));
                flight.setAirline(rs.getString("airline"));
                flight.setDepartureCity(rs.getString("departure_city"));
                flight.setDepartureAirport(rs.getString("departure_airport"));
                flight.setArrivalCity(rs.getString("arrival_city"));
                flight.setArrivalAirport(rs.getString("arrival_airport"));
                flight.setDepartureTime(rs.getTimestamp("departure_time"));
                flight.setArrivalTime(rs.getTimestamp("arrival_time"));
                flight.setDuration(rs.getString("duration"));
                flight.setAircraft(rs.getString("aircraft"));
                flight.setEconomyPrice(rs.getDouble("economy_price"));
                flight.setBusinessPrice(rs.getDouble("business_price"));
                flight.setFirstClassPrice(rs.getDouble("first_class_price"));
                flight.setSeatsEconomy(rs.getInt("seats_economy"));
                flight.setSeatsBusiness(rs.getInt("seats_business"));
                flight.setSeatsFirstClass(rs.getInt("seats_first_class"));
                return flight;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(rs, ps, conn);
        }
        return null;
    }
}