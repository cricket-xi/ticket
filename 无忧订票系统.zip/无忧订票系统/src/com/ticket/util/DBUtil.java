package com.ticket.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
    private static String url;
    private static String username;
    private static String password;
    private static String driver;

    static {
        try {
            // 加载配置文件
            InputStream is = DBUtil.class.getClassLoader().getResourceAsStream("db.properties");
            if (is == null) {
                System.out.println("=== 错误：未找到 db.properties 配置文件 ===");
                throw new RuntimeException("db.properties 文件不存在");
            }

            Properties props = new Properties();
            props.load(is);

            // 读取配置参数
            url = props.getProperty("url");
            username = props.getProperty("username");
            password = props.getProperty("password");
            driver = props.getProperty("driver");

            // 验证配置参数是否完整
            if (url == null || username == null || password == null || driver == null) {
                System.out.println("=== 错误：db.properties 配置不完整 ===");
                System.out.println("url: " + url);
                System.out.println("username: " + username);
                System.out.println("password: " + (password == null ? "null" : "******"));
                System.out.println("driver: " + driver);
                throw new RuntimeException("db.properties 配置缺失");
            }

            // 加载驱动
            Class.forName(driver);
            System.out.println("=== 数据库驱动加载成功（driver: " + driver + "） ===");

        } catch (IOException e) {
            System.out.println("=== 错误：读取 db.properties 失败 ===");
            e.printStackTrace();
            throw new RuntimeException("读取数据库配置文件失败");
        } catch (ClassNotFoundException e) {
            System.out.println("=== 错误：数据库驱动类未找到（driver: " + driver + "） ===");
            e.printStackTrace();
            throw new RuntimeException("数据库驱动加载失败");
        }
    }

    // 获取数据库连接（带日志）
    public static Connection getConnection() throws SQLException {
        try {
            Connection conn = DriverManager.getConnection(url, username, password);
            System.out.println("=== 数据库连接成功！连接信息：" + url + "，用户：" + username + " ===");
            return conn;
        } catch (SQLException e) {
            System.out.println("=== 数据库连接失败！ ===");
            System.out.println("连接信息：" + url);
            System.out.println("错误原因：" + e.getMessage());
            throw e; // 抛出异常，让调用者处理
        }
    }

    // 关闭资源（自动关闭所有实现AutoCloseable的资源）
    public static void close(AutoCloseable... resources) {
        for (AutoCloseable resource : resources) {
            if (resource != null) {
                try {
                    resource.close();
                } catch (Exception e) {
                    System.out.println("=== 关闭资源失败 ===");
                    e.printStackTrace();
                }
            }
        }
    }
}
