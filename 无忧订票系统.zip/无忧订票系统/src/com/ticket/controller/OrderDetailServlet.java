package com.ticket.controller;

import com.ticket.dao.OrderDetailDao;
import com.ticket.model.OrderDetail;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/orders/detail")
public class OrderDetailServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private OrderDetailDao orderDetailDao = new OrderDetailDao();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 1. 获取订单ID参数
        String orderIdStr = request.getParameter("id");

        // 2. 验证参数
        if (orderIdStr == null || orderIdStr.trim().isEmpty()) {
            request.setAttribute("error", "订单ID不存在");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
            return;
        }

        try {
            // 3. 转换订单ID为整数
            int orderId = Integer.parseInt(orderIdStr);

            // 4. 查询订单详情
            List<OrderDetail> orderDetails = orderDetailDao.findByOrderId(orderId);

            // 打印调试信息（部署时可删除）
            System.out.println("查询到订单ID=" + orderId + "的详情数量：" + orderDetails.size());

            // 5. 将数据设置到请求属性中
            request.setAttribute("orderDetails", orderDetails);

            // 6. 转发到订单详情页面
            request.getRequestDispatcher("/WEB-INF/jsp/orderDetail.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            // 处理订单ID格式错误
            request.setAttribute("error", "无效的订单ID");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        } catch (Exception e) {
            // 处理其他异常
            e.printStackTrace();
            request.setAttribute("error", "查询订单详情失败，请稍后重试");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 订单详情一般不需要POST请求，直接调用GET处理
        doGet(request, response);
    }
}
