package com.ticket.controller;

import com.ticket.model.Flight;
import com.ticket.model.Order;
import com.ticket.model.OrderDetail;
import com.ticket.model.User;
import com.ticket.service.FlightService;
import com.ticket.service.OrderService;
import com.ticket.service.PassengerService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet("/payment/*")
public class PaymentServlet extends HttpServlet {
    private OrderService orderService = new OrderService();
    private FlightService flightService = new FlightService();
    private PassengerService passengerService = new PassengerService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getPathInfo();
        // 打印请求路径，便于调试
        System.out.println("=== 收到GET请求，路径：" + action + " ===");

        if (action == null || action.equals("/")) {
            showPaymentPage(req, resp); // 显示支付页面
        } else if (action.equals("/success")) {
            showSuccessPage(req, resp); // 支付成功页面
        } else if (action.equals("/fail")) {
            showFailPage(req, resp); // 支付失败页面
        } else {
            // 未知路径统一跳转到订单列表
            resp.sendRedirect(req.getContextPath() + "/orders");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getPathInfo();
        System.out.println("=== 收到POST请求，路径：" + action + " ===");

        if (action != null && action.equals("/process")) {
            processPayment(req, resp); // 处理支付（核心修复）
        } else {
            resp.sendRedirect(req.getContextPath() + "/payment");
        }
    }

    // 显示支付页面（支持两种场景：1.从乘客选择跳转 2.从订单列表重新支付）
    private void showPaymentPage(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");

        // 未登录跳转登录页
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login?redirect=payment");
            return;
        }

        // 场景1：从订单列表跳转（重新支付），获取orderId
        String orderIdStr = req.getParameter("orderId");
        if (orderIdStr != null && !orderIdStr.isEmpty()) {
            try {
                int orderId = Integer.parseInt(orderIdStr);
                Order order = orderService.getOrderById(orderId);

                // 验证订单合法性
                if (order == null || order.getUserId() != user.getId()) {
                    req.setAttribute("error", "订单不存在或无权限访问");
                    resp.sendRedirect(req.getContextPath() + "/orders");
                    return;
                }

                // 加载航班和乘客信息
                Flight flight = flightService.getFlightById(order.getFlightId());
                List<com.ticket.model.Passenger> passengers = new ArrayList<>();
                List<OrderDetail> details = orderService.getOrderDetails(orderId);
                for (OrderDetail detail : details) {
                    passengers.add(passengerService.getPassengerById(detail.getPassengerId()));
                }

                // 存储会话数据（供支付处理使用）
                session.setAttribute("selectedFlightId", String.valueOf(flight.getId()));
                session.setAttribute("selectedCabinTypeName", order.getCabinType());
                session.setAttribute("pricePerPerson", order.getTotalPrice() / order.getPassengerCount());
                session.setAttribute("totalPrice", order.getTotalPrice());
                session.setAttribute("passengerCount", order.getPassengerCount());
                session.setAttribute("selectedPassengerIds", details.stream()
                        .map(d -> String.valueOf(d.getPassengerId()))
                        .toArray(String[]::new));

                // 传递数据到页面
                req.setAttribute("flight", flight);
                req.setAttribute("passengers", passengers);
                req.getRequestDispatcher("/WEB-INF/jsp/payment.jsp").forward(req, resp);
                return;

            } catch (NumberFormatException e) {
                req.setAttribute("error", "订单ID格式错误");
                resp.sendRedirect(req.getContextPath() + "/orders");
                return;
            }
        }

        // 场景2：从乘客选择页面跳转（首次支付）
        String flightIdStr = (String) session.getAttribute("selectedFlightId");
        String[] passengerIds = (String[]) session.getAttribute("selectedPassengerIds");
        if (flightIdStr == null || passengerIds == null) {
            req.setAttribute("error", "请先选择航班和乘客");
            resp.sendRedirect(req.getContextPath() + "/purchase");
            return;
        }

        try {
            int flightId = Integer.parseInt(flightIdStr);
            Flight flight = flightService.getFlightById(flightId);
            if (flight == null) {
                req.setAttribute("error", "所选航班不存在");
                resp.sendRedirect(req.getContextPath() + "/purchase");
                return;
            }

            // 加载乘客信息
            List<com.ticket.model.Passenger> passengers = new ArrayList<>();
            for (String id : passengerIds) {
                passengers.add(passengerService.getPassengerById(Integer.parseInt(id)));
            }

            req.setAttribute("flight", flight);
            req.setAttribute("passengers", passengers);
            req.getRequestDispatcher("/WEB-INF/jsp/payment.jsp").forward(req, resp);

        } catch (NumberFormatException e) {
            req.setAttribute("error", "航班ID格式错误");
            resp.sendRedirect(req.getContextPath() + "/purchase");
        }
    }

    // 处理支付（核心修复：确保跳转逻辑可靠）
    private void processPayment(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");

        // 未登录拦截
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login?redirect=payment");
            return;
        }

        try {
            // 1. 关键修复：从POST请求中获取status参数（通过表单隐藏域传递）
            String payStatus = req.getParameter("status");
            System.out.println("=== 支付状态参数：" + payStatus + " ===");

            // 验证支付状态参数
            if (payStatus == null || (!"success".equals(payStatus) && !"fail".equals(payStatus))) {
                req.setAttribute("error", "支付参数异常，请重试");
                showPaymentPage(req, resp);
                return;
            }

            // 2. 从会话加载订单数据
            String[] passengerIds = (String[]) session.getAttribute("selectedPassengerIds");
            String flightIdStr = (String) session.getAttribute("selectedFlightId");
            String cabinTypeName = (String) session.getAttribute("selectedCabinTypeName");
            double pricePerPerson = (double) session.getAttribute("pricePerPerson");
            double totalPrice = (double) session.getAttribute("totalPrice");
            int passengerCount = (int) session.getAttribute("passengerCount");

            // 验证会话数据完整性
            if (passengerIds == null || flightIdStr == null || cabinTypeName == null) {
                req.setAttribute("error", "订单数据缺失，请重新选择航班和乘客");
                resp.sendRedirect(req.getContextPath() + "/purchase");
                return;
            }

            // 3. 验证航班存在
            int flightId = Integer.parseInt(flightIdStr);
            Flight flight = flightService.getFlightById(flightId);
            if (flight == null) {
                req.setAttribute("error", "航班不存在，请重新选择");
                resp.sendRedirect(req.getContextPath() + "/purchase");
                return;
            }

            // 4. 创建订单（初始状态为pending）
            Order order = new Order();
            order.setUserId(user.getId());
            order.setFlightId(flightId);
            order.setCabinType(cabinTypeName);
            order.setFlightNumber(flight.getFlightNumber());
            order.setPassengerCount(passengerCount);
            order.setTotalPrice(totalPrice);
            order.setStatus("pending"); // 初始状态：待支付
            order.setCreatedAt(new Date());

            // 创建订单详情
            List<OrderDetail> details = new ArrayList<>();
            for (String id : passengerIds) {
                OrderDetail detail = new OrderDetail();
                detail.setPassengerId(Integer.parseInt(id));
                detail.setPrice(pricePerPerson);
                details.add(detail);
            }

            // 保存订单
            int orderId = orderService.createOrder(order, details);
            System.out.println("=== 订单创建结果：orderId=" + orderId + " ===");
            if (orderId <= 0) {
                req.setAttribute("error", "创建订单失败，请重试");
                showPaymentPage(req, resp);
                return;
            }

            // 5. 根据支付状态处理跳转（核心修复：确保无论状态更新是否成功都跳转）
            String contextPath = req.getContextPath();
            clearSessionData(session); // 提前清理会话，避免数据残留

            if ("success".equals(payStatus)) {
                // 尝试更新订单状态为已支付
                boolean updateSuccess = orderService.payOrder(orderId);
                System.out.println("=== 订单状态更新结果：" + updateSuccess + " ===");

                // 关键修复：即使状态更新失败，也跳转到成功页面（避免用户滞留）
                String successUrl = contextPath + "/payment/success?orderId=" + orderId;
                if (!updateSuccess) {
                    successUrl += "&warn=订单已创建，但支付状态更新延迟，请稍后查看订单列表";
                }
                System.out.println("=== 跳转支付成功页面：" + successUrl + " ===");
                resp.sendRedirect(successUrl);

            } else if ("fail".equals(payStatus)) {
                // 支付失败，跳转到失败页面
                String failUrl = contextPath + "/payment/fail?orderId=" + orderId + "&errorMsg=模拟支付失败（余额不足或网络异常）";
                System.out.println("=== 跳转支付失败页面：" + failUrl + " ===");
                resp.sendRedirect(failUrl);
            }

        } catch (Exception e) {
            // 捕获所有异常，避免白屏
            System.err.println("=== 支付处理异常：" + e.getMessage() + " ===");
            e.printStackTrace();
            req.setAttribute("error", "支付过程出错：" + e.getMessage());
            showPaymentPage(req, resp);
        }
    }

    // 显示支付成功页面（修复跳转拦截逻辑）
    private void showSuccessPage(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String orderIdStr = req.getParameter("orderId");
        String warnMsg = req.getParameter("warn");
        System.out.println("=== 访问支付成功页面，orderId：" + orderIdStr + " ===");

        // 缺失orderId参数，跳转到订单列表
        if (orderIdStr == null || orderIdStr.trim().isEmpty()) {
            req.setAttribute("error", "缺少订单ID参数");
            resp.sendRedirect(req.getContextPath() + "/orders");
            return;
        }

        try {
            int orderId = Integer.parseInt(orderIdStr);
            Order order = orderService.getOrderById(orderId);

            // 订单不存在，跳转到订单列表
            if (order == null) {
                req.setAttribute("error", "订单不存在");
                resp.sendRedirect(req.getContextPath() + "/orders");
                return;
            }

            // 验证订单归属（修复跳转路径：无权限跳订单列表而非购买页）
            HttpSession session = req.getSession();
            User user = (User) session.getAttribute("user");
            if (user == null) {
                resp.sendRedirect(req.getContextPath() + "/login?redirect=payment/success?orderId=" + orderId);
                return;
            }
            if (order.getUserId() != user.getId()) {
                req.setAttribute("error", "无权限访问此订单");
                resp.sendRedirect(req.getContextPath() + "/orders");
                return;
            }

            // 传递数据到页面
            List<OrderDetail> details = orderService.getOrderDetails(orderId);
            req.setAttribute("order", order);
            req.setAttribute("details", details);
            req.setAttribute("warnMsg", warnMsg); // 传递警告信息
            System.out.println("=== 成功加载支付成功页面，orderId：" + orderId + " ===");
            req.getRequestDispatcher("/WEB-INF/jsp/success.jsp").forward(req, resp);

        } catch (NumberFormatException e) {
            req.setAttribute("error", "订单ID格式错误");
            resp.sendRedirect(req.getContextPath() + "/orders");
        }
    }

    // 显示支付失败页面（统一跳转逻辑）
    private void showFailPage(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String orderIdStr = req.getParameter("orderId");
        String errorMsg = req.getParameter("errorMsg");
        System.out.println("=== 访问支付失败页面，orderId：" + orderIdStr + " ===");

        if (orderIdStr == null || orderIdStr.trim().isEmpty()) {
            req.setAttribute("error", "缺少订单ID参数");
            resp.sendRedirect(req.getContextPath() + "/orders");
            return;
        }

        try {
            int orderId = Integer.parseInt(orderIdStr);
            Order order = orderService.getOrderById(orderId);

            if (order == null) {
                req.setAttribute("error", "订单不存在");
                resp.sendRedirect(req.getContextPath() + "/orders");
                return;
            }

            // 验证订单归属
            HttpSession session = req.getSession();
            User user = (User) session.getAttribute("user");
            if (user == null) {
                resp.sendRedirect(req.getContextPath() + "/login?redirect=payment/fail?orderId=" + orderId);
                return;
            }
            if (order.getUserId() != user.getId()) {
                req.setAttribute("error", "无权限访问此订单");
                resp.sendRedirect(req.getContextPath() + "/orders");
                return;
            }

            // 传递数据到页面
            req.setAttribute("order", order);
            req.setAttribute("errorMsg", errorMsg);
            System.out.println("=== 成功加载支付失败页面，orderId：" + orderId + " ===");
            req.getRequestDispatcher("/WEB-INF/jsp/fail.jsp").forward(req, resp);

        } catch (NumberFormatException e) {
            req.setAttribute("error", "订单ID格式错误");
            resp.sendRedirect(req.getContextPath() + "/orders");
        }
    }

    // 工具方法：清理会话临时数据
    private void clearSessionData(HttpSession session) {
        session.removeAttribute("selectedPassengerIds");
        session.removeAttribute("selectedFlightId");
        session.removeAttribute("selectedCabinType");
        session.removeAttribute("selectedCabinTypeName");
        session.removeAttribute("pricePerPerson");
        session.removeAttribute("totalPrice");
        session.removeAttribute("passengerCount");
        System.out.println("=== 会话临时数据已清理 ===");
    }
}