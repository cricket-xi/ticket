package com.ticket.controller;

import com.ticket.model.User;
import com.ticket.service.UserService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
@WebServlet("/login")

public class LoginServlet extends HttpServlet {
    private UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 日志：记录GET请求到达
        System.out.println("=== LoginServlet doGet 方法被调用（浏览器直接访问） ===");

        // GET请求时，跳转到登录页面
        req.getRequestDispatcher("/WEB-INF/jsp/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 保留原有的doPost逻辑（处理表单提交）
        System.out.println("=== LoginServlet doPost 方法被调用 ===");

        req.setCharacterEncoding("UTF-8");
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        System.out.println("接收的登录参数：username=" + username + "，password=" + password);

        User user = userService.login(username, password);
        System.out.println("userService.login 返回结果：user=" + (user == null ? "NULL" : "非NULL"));

        if (user != null) {
            System.out.println("=== 登录成功，重定向到 /purchase ===");
            HttpSession session = req.getSession();
            session.setAttribute("user", user);
            resp.sendRedirect(req.getContextPath() + "/purchase");
        } else {
            System.out.println("=== 登录失败，返回登录页 ===");
            req.setAttribute("error", "用户名或密码错误");
            req.getRequestDispatcher("/WEB-INF/jsp/login.jsp").forward(req, resp);
        }
    }
}