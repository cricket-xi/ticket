package com.ticket.controller;

import com.ticket.model.Order;
import com.ticket.model.OrderDetail;
import com.ticket.model.User;
import com.ticket.service.OrderService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/orders/*")
public class OrderServlet extends HttpServlet {
    private OrderService orderService = new OrderService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getPathInfo();

        if (action == null || action.equals("/")) {
            // 显示用户所有订单
            showUserOrders(req, resp);
        } else if (action.equals("/detail")) {
            // 显示订单详情
            showOrderDetail(req, resp);
        } else if (action.equals("/cancel")) {
            // 取消订单
            cancelOrder(req, resp);
        } else if (action.equals("/refund")) {
            // 申请退款
            applyRefund(req, resp);
        } else {
            resp.sendRedirect(req.getContextPath() + "/orders");
        }
    }

    // 显示用户所有订单
    private void showUserOrders(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");

        // 验证登录状态
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        List<Order> orders = orderService.getUserOrders(user.getId());
        // 新增日志：打印订单数量，确认数据是否获取成功
        System.out.println("=== 为用户ID=" + user.getId() + "查询到订单数量：" + orders.size() + " ===");

        req.setAttribute("orders", orders);
        // 确保转发路径与JSP文件名一致
        req.getRequestDispatcher("/WEB-INF/jsp/order.jsp").forward(req, resp);
    }

    // 显示订单详情
    private void showOrderDetail(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String orderIdStr = req.getParameter("id");
        if (orderIdStr == null) {
            resp.sendRedirect(req.getContextPath() + "/orders");
            return;
        }

        int orderId = Integer.parseInt(orderIdStr);
        Order order = orderService.getOrderById(orderId);

        if (order == null) {
            resp.sendRedirect(req.getContextPath() + "/orders");
            return;
        }

        // 检查订单是否属于当前用户
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");
        if (order.getUserId() != user.getId()) {
            resp.sendRedirect(req.getContextPath() + "/orders");
            return;
        }

        // 获取订单详情
        List<OrderDetail> details = orderService.getOrderDetails(orderId);

        req.setAttribute("order", order);
        req.setAttribute("details", details);

        req.getRequestDispatcher("/WEB-INF/jsp/orderDetail.jsp").forward(req, resp);
    }

    // 取消订单
    private void cancelOrder(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");

        // 验证登录状态
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        String orderIdStr = req.getParameter("id");
        if (orderIdStr == null) {
            session.setAttribute("cancelError", "订单ID不存在");
            resp.sendRedirect(req.getContextPath() + "/orders");
            return;
        }

        try {
            int orderId = Integer.parseInt(orderIdStr);
            Order order = orderService.getOrderById(orderId);

            // 验证订单是否存在且属于当前用户
            if (order == null || order.getUserId() != user.getId()) {
                session.setAttribute("cancelError", "订单不存在或无权限操作");
                resp.sendRedirect(req.getContextPath() + "/orders");
                return;
            }

            // 验证订单状态是否为待支付
            if (!"pending".equals(order.getStatus())) {
                session.setAttribute("cancelError", "只有待支付的订单可以取消");
                resp.sendRedirect(req.getContextPath() + "/orders");
                return;
            }

            // 执行取消订单操作
            boolean success = orderService.cancelOrder(orderId);
            if (success) {
                session.setAttribute("cancelSuccess", "订单取消成功");
            } else {
                session.setAttribute("cancelError", "订单取消失败，请稍后重试");
            }
        } catch (NumberFormatException e) {
            session.setAttribute("cancelError", "无效的订单ID");
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("cancelError", "处理取消订单时发生错误");
        }

        resp.sendRedirect(req.getContextPath() + "/orders");
    }

    // 申请退款
    private void applyRefund(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");

        // 验证登录状态
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        String orderIdStr = req.getParameter("id");
        if (orderIdStr == null) {
            session.setAttribute("refundError", "订单ID不存在");
            resp.sendRedirect(req.getContextPath() + "/orders");
            return;
        }

        try {
            int orderId = Integer.parseInt(orderIdStr);
            Order order = orderService.getOrderById(orderId);

            // 验证订单是否存在且属于当前用户
            if (order == null || order.getUserId() != user.getId()) {
                session.setAttribute("refundError", "订单不存在或无权限操作");
                resp.sendRedirect(req.getContextPath() + "/orders");
                return;
            }

            // 验证订单状态是否为已支付
            if (!"paid".equals(order.getStatus())) {
                session.setAttribute("refundError", "只有已支付的订单可以申请退款");
                resp.sendRedirect(req.getContextPath() + "/orders");
                return;
            }

            // 执行申请退款操作
            boolean success = orderService.applyRefund(orderId);
            if (success) {
                session.setAttribute("refundSuccess", "退款申请已提交，请等待处理");
            } else {
                session.setAttribute("refundError", "退款申请提交失败，请稍后重试");
            }
        } catch (NumberFormatException e) {
            session.setAttribute("refundError", "无效的订单ID");
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("refundError", "处理退款申请时发生错误");
        }

        resp.sendRedirect(req.getContextPath() + "/orders");
    }
}