package com.ticket.controller;

import com.ticket.model.User;
import com.ticket.service.UserService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet; // 导入注解
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

// 关键：添加注解，将Servlet映射到/register路径
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // GET请求：跳转到注册页面
        req.getRequestDispatcher("/WEB-INF/jsp/register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // POST请求：处理注册逻辑
        req.setCharacterEncoding("UTF-8"); // 解决中文乱码
        User user = new User();
        user.setUsername(req.getParameter("username"));
        user.setPassword(req.getParameter("password"));
        user.setFullName(req.getParameter("fullName"));
        user.setEmail(req.getParameter("email"));
        user.setPhone(req.getParameter("phone"));

        boolean success = userService.register(user);
        if (success) {
            // 注册成功，重定向到登录页并携带成功标识
            resp.sendRedirect(req.getContextPath() + "/login?registerSuccess=true");
        } else {
            // 注册失败，回显错误信息
            req.setAttribute("error", "注册失败，用户名可能已存在");
            req.setAttribute("user", user);
            req.getRequestDispatcher("/WEB-INF/jsp/register.jsp").forward(req, resp);
        }
    }
}
