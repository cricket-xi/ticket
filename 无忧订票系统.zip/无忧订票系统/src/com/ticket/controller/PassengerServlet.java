package com.ticket.controller;

import com.ticket.model.Flight;
import com.ticket.model.Passenger;
import com.ticket.model.User;
import com.ticket.service.FlightService;
import com.ticket.service.PassengerService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/passengers/*")
public class PassengerServlet extends HttpServlet {
    private PassengerService passengerService = new PassengerService();
    private FlightService flightService = new FlightService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getPathInfo();
        if (action == null || action.equals("/select")) {
            showSelectPassengers(req, resp);
        } else {
            resp.sendRedirect(req.getContextPath() + "/purchase");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getPathInfo();
        if (action.equals("/add")) {
            addPassenger(req, resp);
        } else if (action.equals("/confirm")) {
            confirmPassengers(req, resp); // 核心修改：处理舱位价格
        } else {
            resp.sendRedirect(req.getContextPath() + "/purchase");
        }
    }

    // 显示选择乘客页面（保持不变）
    private void showSelectPassengers(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        String flightIdStr = req.getParameter("flightId");
        if (flightIdStr == null || flightIdStr.isEmpty()) {
            resp.sendRedirect(req.getContextPath() + "/purchase");
            return;
        }

        try {
            int flightId = Integer.parseInt(flightIdStr);
            Flight flight = flightService.getFlightById(flightId);
            if (flight == null) {
                resp.sendRedirect(req.getContextPath() + "/purchase");
                return;
            }

            List<Passenger> passengers = passengerService.getPassengersByUserId(user.getId());
            req.setAttribute("flight", flight);
            req.setAttribute("passengers", passengers);
            req.getRequestDispatcher("/WEB-INF/jsp/selectPassenger.jsp").forward(req, resp);
        } catch (NumberFormatException e) {
            resp.sendRedirect(req.getContextPath() + "/purchase");
        }
    }

    // 添加乘客（保持不变）
    private void addPassenger(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        req.setCharacterEncoding("UTF-8");
        System.out.println("=== 从表单接收的参数 ===");
        System.out.println("姓名：" + req.getParameter("name"));
        System.out.println("身份证号：" + req.getParameter("idCard"));
        System.out.println("手机号：" + req.getParameter("phone"));
        System.out.println("乘客类型：" + req.getParameter("type"));
        System.out.println("当前登录用户ID：" + user.getId());

        Passenger passenger = new Passenger();
        passenger.setUserId(user.getId());
        passenger.setName(req.getParameter("name"));
        passenger.setIdCard(req.getParameter("idCard"));
        passenger.setPhone(req.getParameter("phone"));
        passenger.setType(req.getParameter("type"));

        boolean success = passengerService.addPassenger(passenger);
        System.out.println("添加乘客结果：" + (success ? "成功" : "失败"));

        String flightId = req.getParameter("flightId");
        resp.sendRedirect(req.getContextPath() + "/passengers/select?flightId=" + flightId);
    }

    // 确认乘客选择（核心修改：计算舱位价格并存入会话）
    private void confirmPassengers(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String[] passengerIds = req.getParameterValues("passengerId");
        String flightIdStr = req.getParameter("flightId");
        String cabinType = req.getParameter("cabinType"); // 此时接收的是英文标识（economy/business/first_class）

        // 1. 验证参数完整性
        if (passengerIds == null || passengerIds.length == 0 || flightIdStr == null || cabinType == null) {
            resp.sendRedirect(req.getContextPath() + "/passengers/select?flightId=" + flightIdStr + "&error=请选择乘客和舱位");
            return;
        }

        // 2. 获取各舱位价格（从前端隐藏域传递）
        double economyPrice = Double.parseDouble(req.getParameter("economyPrice"));
        double businessPrice = Double.parseDouble(req.getParameter("businessPrice"));
        double firstClassPrice = Double.parseDouble(req.getParameter("firstClassPrice"));

        // 3. 根据舱位类型计算单价和总价
        double pricePerPerson = 0.0;
        String cabinTypeName = ""; // 用于页面显示的中文名称
        switch (cabinType) {
            case "business":
                pricePerPerson = businessPrice;
                cabinTypeName = "商务舱";
                break;
            case "first_class":
                pricePerPerson = firstClassPrice;
                cabinTypeName = "头等舱"; // 中文名称，供支付页面显示
                break;
            default: // economy
                pricePerPerson = economyPrice;
                cabinTypeName = "经济舱";
                break;
        }
        int passengerCount = passengerIds.length;
        double totalPrice = pricePerPerson * passengerCount;

        // 4. 将所有数据存入会话，供支付页面和订单创建使用
        HttpSession session = req.getSession();
        session.setAttribute("selectedPassengerIds", passengerIds);
        session.setAttribute("selectedFlightId", flightIdStr);
        session.setAttribute("selectedCabinType", cabinType); // 英文标识（用于后端逻辑）
        session.setAttribute("selectedCabinTypeName", cabinTypeName); // 中文名称（用于页面显示）
        session.setAttribute("pricePerPerson", pricePerPerson); // 单价
        session.setAttribute("totalPrice", totalPrice); // 总价
        session.setAttribute("passengerCount", passengerCount); // 乘客数量

        // 5. 跳转到支付页面
        resp.sendRedirect(req.getContextPath() + "/payment");
    }
}