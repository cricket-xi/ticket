package com.ticket.controller;
import com.ticket.model.Flight;
import com.ticket.model.User;
import com.ticket.service.FlightService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/searchFlights")
public class FlightSearchServlet extends HttpServlet {
    private FlightService flightService = new FlightService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");

        // 未登录跳转登录页
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // 设置请求编码，解决中文乱码
        req.setCharacterEncoding("UTF-8");

        // 1. 获取基础搜索参数
        String departureCity = req.getParameter("departureCity");
        String arrivalCity = req.getParameter("arrivalCity");
        String date = req.getParameter("date");
        String passengers = req.getParameter("passengers");
        String cabin = req.getParameter("cabin");

        // 2. 获取筛选参数（航空公司、出发时间范围）
        String selectedAirline = req.getParameter("selectedAirline");
        String selectedTimeRange = req.getParameter("selectedTimeRange");

        // 3. 获取排序参数
        String sortBy = req.getParameter("sortBy");

        // 4. 调用Service层搜索航班（传递所有参数）
        List<Flight> flights = flightService.searchFlights(
                departureCity,
                arrivalCity,
                date,
                selectedAirline,
                selectedTimeRange,
                sortBy
        );

        // 5. 传递参数到前端（用于回显选中状态）
        req.setAttribute("flights", flights);
        req.setAttribute("departureCity", departureCity);
        req.setAttribute("arrivalCity", arrivalCity);
        req.setAttribute("date", date);
        req.setAttribute("passengers", passengers);
        req.setAttribute("cabin", cabin);
        req.setAttribute("selectedAirline", selectedAirline);
        req.setAttribute("selectedTimeRange", selectedTimeRange);
        req.setAttribute("sortBy", sortBy);

        // 6. 转发到航班列表页面
        req.getRequestDispatcher("/WEB-INF/jsp/purchase.jsp").forward(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 支持GET请求（如刷新页面时）
        doPost(req, resp);
    }
}
