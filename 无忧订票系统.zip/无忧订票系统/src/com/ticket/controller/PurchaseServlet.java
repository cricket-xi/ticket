package com.ticket.controller; // 替换为实际包路径

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

// 注解方式映射路径（或在web.xml中配置）
public class PurchaseServlet extends HttpServlet {
    @Override
    public void init() throws ServletException {
        System.out.println("=== PurchaseServlet 初始化成功 ===");
    }
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Object user = session.getAttribute("user");
        System.out.println("=== PurchaseServlet doGet 被调用，user=" + (user != null ? "已登录" : "未登录") + " ===");

        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // 确认是否执行到此处
        System.out.println("=== 准备跳转至 purchase.jsp ===");
        req.getRequestDispatcher("/WEB-INF/jsp/purchase.jsp").forward(req, resp);
    }
}
