package com.ticket.model;

public class OrderDetail {
    private int id;
    private int orderId;
    private int passengerId;
    private double price;
    private String passengerName;
    private String passengerIdCard;

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getOrderId() { return orderId; }
    public void setOrderId(int orderId) { this.orderId = orderId; }

    public int getPassengerId() { return passengerId; }
    public void setPassengerId(int passengerId) { this.passengerId = passengerId; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String getPassengerName() { return passengerName; }
    public void setPassengerName(String passengerName) { this.passengerName = passengerName; }

    public String getPassengerIdCard() { return passengerIdCard; }
    public void setPassengerIdCard(String passengerIdCard) { this.passengerIdCard = passengerIdCard; }
}
