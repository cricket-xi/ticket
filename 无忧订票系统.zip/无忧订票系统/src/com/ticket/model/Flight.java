package com.ticket.model;

import java.util.Date;

public class Flight {
    private int id;
    private String flightNumber;
    private String airline;
    private String departureCity;
    private String departureAirport;
    private String arrivalCity;
    private String arrivalAirport;
    private Date departureTime;
    private Date arrivalTime;
    private String duration;
    private String aircraft;
    private double economyPrice;
    private double businessPrice;
    private double firstClassPrice;
    private int seatsEconomy;
    private int seatsBusiness;
    private int seatsFirstClass;

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getFlightNumber() { return flightNumber; }
    public void setFlightNumber(String flightNumber) { this.flightNumber = flightNumber; }

    public String getAirline() { return airline; }
    public void setAirline(String airline) { this.airline = airline; }

    public String getDepartureCity() { return departureCity; }
    public void setDepartureCity(String departureCity) { this.departureCity = departureCity; }

    public String getDepartureAirport() { return departureAirport; }
    public void setDepartureAirport(String departureAirport) { this.departureAirport = departureAirport; }

    public String getArrivalCity() { return arrivalCity; }
    public void setArrivalCity(String arrivalCity) { this.arrivalCity = arrivalCity; }

    public String getArrivalAirport() { return arrivalAirport; }
    public void setArrivalAirport(String arrivalAirport) { this.arrivalAirport = arrivalAirport; }

    public Date getDepartureTime() { return departureTime; }
    public void setDepartureTime(Date departureTime) { this.departureTime = departureTime; }

    public Date getArrivalTime() { return arrivalTime; }
    public void setArrivalTime(Date arrivalTime) { this.arrivalTime = arrivalTime; }

    public String getDuration() { return duration; }
    public void setDuration(String duration) { this.duration = duration; }

    public String getAircraft() { return aircraft; }
    public void setAircraft(String aircraft) { this.aircraft = aircraft; }

    public double getEconomyPrice() { return economyPrice; }
    public void setEconomyPrice(double economyPrice) { this.economyPrice = economyPrice; }

    public double getBusinessPrice() { return businessPrice; }
    public void setBusinessPrice(double businessPrice) { this.businessPrice = businessPrice; }

    public double getFirstClassPrice() { return firstClassPrice; }
    public void setFirstClassPrice(double firstClassPrice) { this.firstClassPrice = firstClassPrice; }

    public int getSeatsEconomy() { return seatsEconomy; }
    public void setSeatsEconomy(int seatsEconomy) { this.seatsEconomy = seatsEconomy; }

    public int getSeatsBusiness() { return seatsBusiness; }
    public void setSeatsBusiness(int seatsBusiness) { this.seatsBusiness = seatsBusiness; }

    public int getSeatsFirstClass() { return seatsFirstClass; }
    public void setSeatsFirstClass(int seatsFirstClass) { this.seatsFirstClass = seatsFirstClass; }
}
