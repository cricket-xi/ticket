    package com.ticket.model;

    import java.sql.Timestamp;
    import java.util.Date;

    public class Order {
        private int id;
        private String orderNumber;
        private int userId;
        private int flightId;
        private String cabinType; // economy, business, first_class
        private double totalPrice;
        private String status; // pending, paid, completed, cancelled
        private Date createdAt;


        // 非数据库字段，用于页面展示
        private String flightNumber;
        private String airline;
        private String departureCity;
        private String arrivalCity;
        private Date departureTime;
        private Date arrivalTime;
        // 添加缺少的字段
        private String departureAirport;  // 出发机场
        private String arrivalAirport;    // 到达机场
        private int passengerCount;

        // 已有的getter和setter方法...

        // 添加新字段的getter和setter方法
        public String getDepartureAirport() {
            return departureAirport;
        }

        public void setDepartureAirport(String departureAirport) {
            this.departureAirport = departureAirport;
        }

        public String getArrivalAirport() {
            return arrivalAirport;
        }

        public void setArrivalAirport(String arrivalAirport) {
            this.arrivalAirport = arrivalAirport;
        }

        // 如果之前没有添加arrivalTime的setter/getter，也需要补充
        public Date getArrivalTime() {
            return arrivalTime;
        }

        public void setArrivalTime(Date arrivalTime) {
            this.arrivalTime = arrivalTime;
        }

        public void setOrderNumber(String orderNumber) {
            this.orderNumber = orderNumber;
        }

        // 通常也需要对应的getter方法
        public String getOrderNumber() {
            return orderNumber;
        }
        public void setStatus(String status) {
            this.status = status;
        }

        // 同时确保getter方法也存在
        public String getStatus() {
            return status;
        }

        public void setCabinType(String cabinType) {
        }

        public int getUserId() {
            return userId;
        }

        // 同时确保setter方法也存在（如果之前没有）
        public void setUserId(int userId) {
            this.userId = userId;
        }

        public int getFlightId() {
            return flightId;
        }

        // 确保setter方法也存在（如果之前没有）
        public void setFlightId(int flightId) {
            this.flightId = flightId;
        }

        public String getCabinType() {
            return cabinType;
        }

        public double getTotalPrice() {
            return totalPrice;
        }

        // 确保setter方法也存在（如果之前没有）
        public void setTotalPrice(double totalPrice) {
            this.totalPrice = totalPrice;
        }

        public void setId(int id) {
            this.id = id;
        }

        // 确保getter方法也存在（如果之前没有）
        public int getId() {
            return id;
        }

        public void setCreatedAt(Date createdAt) {
            this.createdAt = createdAt;
        }

        // 修改getter方法返回类型为Date
        public Date getCreatedAt() {
            return createdAt;
        }

        public void setFlightNumber(String flightNumber) {
            this.flightNumber = flightNumber;
        }

        // 同时确保getter方法也存在
        public String getFlightNumber() {
            return flightNumber;
        }

        public void setAirline(String airline) {
            this.airline = airline;
        }

        // 同时确保getter方法也存在
        public String getAirline() {
            return airline;
        }

        public void setDepartureCity(String departureCity) {
            this.departureCity = departureCity;
        }

        // 同时确保getter方法也存在
        public String getDepartureCity() {
            return departureCity;
        }

        public void setArrivalCity(String arrivalCity) {
            this.arrivalCity = arrivalCity;
        }

        // 同时确保getter方法也存在
        public String getArrivalCity() {
            return arrivalCity;
        }

        public void setDepartureTime(Date departureTime) {
            this.departureTime = departureTime;
        }

        // 修改getter方法返回类型为Date
        public Date getDepartureTime() {
            return departureTime;
        }
        public int getPassengerCount() {
            return passengerCount;
        }

        public void setPassengerCount(int passengerCount) {
            this.passengerCount = passengerCount;
        }
    }
